const db = require('../config/config');
const bcrypt = require('bcryptjs')

const User = {};

/*==========================================
        OBTENER USUARIOS
==========================================*/
User.getAll = () => {
    
    const sql = `SELECT * FROM usuarios`;

    return db.manyOrNone(sql);
}

/*==========================================
        OBTENER USUARIOS POR ID
==========================================*/
User.getAllById = (id) => {
    
    const sql = `SELECT * FROM usuarios WHERE id = $1`;

    return db.manyOrNone(sql, id);
}

/*==========================================
        GUARDAR USUARIOS
==========================================*/
User.create = async (user) => {

    const hash = await bcrypt.hash(user.password, 10)

    const sql = `INSERT INTO usuarios (id, email, name, lastname, phone, image, password, created_at, updated_at) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING id`;

    return db.oneOrNone(sql, [user.id, user.email, user.name, user.lastname, user.phone, user.image, hash, new Date(), new Date()]);
}

/*==========================================
        MODIFICAR USUARIOS
==========================================*/
User.update = async (user) => {

    const hash = await bcrypt.hash(user.password, 10)

    const sql = `UPDATE usuarios SET email = $2, name = $3, lastname = $4, phone = $5, image = $6, password = $7, updated_at = $8 WHERE id = $1`;

    return db.none(sql, [user.id, user.email, user.name, user.lastname, user.phone, user.image, hash, new Date()]);
}

/*==========================================
        MODIFICAR USUARIOS
==========================================*/
User.delete = (user) => {

    const sql = `DELETE FROM usuarios WHERE id = $1`;

    return db.none(sql, [user.id]);
}

module.exports = User;