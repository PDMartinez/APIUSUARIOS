const User = require('../models/user');
// const Rol = require('../models/rol');
const bcrypt = require('bcryptjs');
const passport = require('passport');
const jwt = require('jsonwebtoken');
const keys = require('../config/keys');
const storage = require('../utils/cloud_storage');

module.exports = {

    /*==========================================
        OBTENER USUARIOS
    ==========================================*/
    async getAll(req, res, next) {
        try {
            const data = await User.getAll();
            console.log(`Usuarios: ${data}`);
            return res.status(201).json(data);
        } 
        catch (error) {
            console.log(`Error: ${error}`);
            return res.status(501).json({
                success: false,
                message: 'Error al obtener los usuarios'
            });
        }
    },

    /*==========================================
        OBTENER USUARIOS POR ID
    ==========================================*/
    async getAllById(req, res, next) {
        try {
            const id = req.params.id;
            const data = await User.getAllById(id);
            console.log(`Usuarios: ${data}`);
            return res.status(201).json(data);
        } 
        catch (error) {
            console.log(`Error: ${error}`);
            return res.status(501).json({
                success: false,
                message: 'Error al obtener los usuarios'
            });
        }
    },

    /*==========================================
        GUARDAR USUARIOS
    ==========================================*/
    async register(req, res, next) {
        
        try {
            
            const user = req.body;
            const data = await User.create(user);

        
            return res.status(201).json({
                success: true,
                message: 'El registro se realizo correctamente',
                data: data.id
            });

        } 
        catch (error) {
            console.log(`Error: ${error}`);
            return res.status(501).json({
                success: false,
                message: 'Hubo un error con el registro del usuario',
                error: error
            });
        }
    },

    /*==========================================
        MODIFICAR USUARIOS
    ==========================================*/
    async update(req, res, next) {
        try {
            
            const user = req.body;
            await User.update(user);
        
            return res.status(201).json({
                success: true,
                message: 'El usuario se ha actualizado correctamente',
                data: user
            });

        } 
        catch (error) {
            console.log(`Error: ${error}`);
            return res.status(501).json({
                success: false,
                message: 'Hubo un error con la actualizacion del usuario',
                error: error
            });
        }
    },

    /*==========================================
        ELIMINAR USUARIOS
    ==========================================*/
    async delete(req, res, next) {
        try {
            
            const user = req.body;
            await User.delete(user);
        
            return res.status(201).json({
                success: true,
                message: 'El usuario se ha eliminado correctamente',
                data: user
            });

        } 
        catch (error) {
            console.log(`Error: ${error}`);
            return res.status(501).json({
                success: false,
                message: 'Hubo un error con la eliminación del usuario',
                error: error
            });
        }
    },


};