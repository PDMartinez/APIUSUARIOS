const UsersController = require('../controllers/usersController');

module.exports = (app, upload) => {

    /*==========================================
        CONSULTAR USUARIOS
    ==========================================*/
    app.get('/api/users/getAll', UsersController.getAll);

    /*==========================================
        CONSULTAR USUARIOS POR ID
    ==========================================*/
    app.get('/api/users/getAll/:id', UsersController.getAllById);

    /*==========================================
        ALMACENAR USUARIOS
    ==========================================*/
    app.post('/api/users/create', UsersController.register);

    /*==========================================
        MODIFICAR USUARIOS
    ==========================================*/
    app.put('/api/users/update', UsersController.update);

    /*==========================================
        ELIMINAR USUARIOS
    ==========================================*/
    app.delete('/api/users/delete', UsersController.delete);
}