
********************************************
                GET
********************************************
http://192.168.1.101:3000/api/users/getAll/

[
    {
        "id": "1",
        "email": "danilo@gmail.com",
        "name": "Danilo",
        "lastname": "Martinez",
        "phone": "0972905218",
        "image": null,
        "password": null,
        "is_available": null,
        "session_token": null,
        "created_at": null,
        "updated_at": null
    }
]

********************************************
                GET BY ID
********************************************
http://192.168.1.101:3000/api/users/getAll/5

[
    {
        "id": "5",
        "email": "danilo@gmail.com",
        "name": "Danilo",
        "lastname": "Martinez",
        "phone": "0972905218",
        "image": null,
        "password": "$2a$10$l8jRgpOx2DfJ1rr0qUUX7eD8oiZtCIjWD/AQIETDx810yzjChcO5K",
        "created_at": "2022-11-16 14:38:19",
        "updated_at": "2022-11-16 17:10:11"
    }
]

********************************************
                POST
********************************************
http://192.168.1.101:3000/api/users/create/

{
    "id": "1",
    "email": "pedro@gmail.com",
    "name": "Pedro",
    "lastname": "Martinez",
    "phone": "0972905218",
    "password": "123"
}

********************************************
                PUT
********************************************
http://192.168.1.101:3000/api/users/update/

{   
    "id": "1",
    "email": "danilo@gmail.com",
    "name": "Danilo",
    "lastname": "Martinez",
    "phone": "0972905218",
    "password": "321"
}

********************************************
                DELETE
********************************************
http://192.168.1.101:3000/api/users/delete/

{   
    "id": "2"
}